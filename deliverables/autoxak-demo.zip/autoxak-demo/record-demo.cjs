'use strict';
const {chromium} = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {spawnSync} = require('node:child_process');

const args = process.argv.slice(2);
function option(name, fallback) {
  const i = args.indexOf(name);
  if (i === -1) return fallback;
  if (!args[i + 1] || args[i + 1].startsWith('--')) throw new Error(`Value required for ${name}`);
  return args[i + 1];
}
const supplied = new URL(option('--url', 'http://localhost:8000'));
if (!['http:', 'https:'].includes(supplied.protocol) || supplied.username || supplied.password || supplied.search || supplied.hash || supplied.pathname !== '/') {
  throw new Error('Use only an HTTP(S) origin without credentials, query, or path.');
}
const base = supplied.origin;
const output = path.join(__dirname, 'output', new Date().toISOString().replace(/[:.]/g, '-'));
fs.mkdirSync(output, {recursive: true});
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

// Only browser sensor inputs are synthetic. Application calculations, HTTP
// responses, balance, persistence and UI counters are never mocked or assigned.
function installSensors() {
  const realNow = Date.now.bind(Date);
  let clock = null, origin = null, index = -1, speed = 0, meters = 0;
  let nextWatch = 0;
  const watches = new Map();
  Date.now = () => clock === null ? realNow() : clock;
  const coords = () => ({latitude: 55.75 + meters / 111194.9266, longitude: 37.61,
    accuracy: 5, speed, altitude: null, altitudeAccuracy: null, heading: 0});
  Object.defineProperty(navigator, 'geolocation', {configurable: true, value: {
    watchPosition(callback) { const id = ++nextWatch; watches.set(id, callback); return id; },
    clearWatch(id) { watches.delete(id); },
    getCurrentPosition(callback) { callback({timestamp: Date.now(), coords: coords()}); }
  }});
  if (typeof DeviceMotionEvent !== 'undefined') Object.defineProperty(DeviceMotionEvent, 'requestPermission', {
    configurable: true, value: () => Promise.resolve('granted')
  });
  const badge = () => {
    if (document.getElementById('synthetic-demo-label')) return;
    const node = document.createElement('div');
    node.id = 'synthetic-demo-label';
    node.textContent = 'ДЕМО · синтетическая поездка';
    node.style.cssText = 'position:fixed;top:3px;right:5px;z-index:2147483647;font:9px sans-serif;color:#d2fa58;background:#121417e6;border-radius:3px;padding:3px 5px;pointer-events:none';
    document.body.append(node);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', badge); else badge();
  window.__autoXAKDemo = {
    advance(last) {
      if (origin === null) origin = realNow();
      for (let i = index + 1; i <= last; i++) {
        const t = i * .02;
        clock = origin + i * 20;
        // Finite 0.2-second ramps avoid instantaneous acceleration steps and
        // keep gentle braking safely away from the event threshold.
        const ramp = (start, end, peak) => t >= start && t < end
          ? peak * Math.min(1, (t - start) / .2, (end - t) / .2) : 0;
        const ax = ramp(4, 10, 1.5) + ramp(20, 22, 3) + ramp(32, 34, -3)
          + ramp(40, 46, -1.5) + ramp(50, 54, 1.5) + ramp(54, 58, -1.5);
        if (i > 0) { speed = Math.max(0, speed + ax * .02); meters += speed * .02; }
        if (i % 50 === 0) for (const callback of watches.values()) callback({timestamp: clock, coords: coords()});
        const z = (t >= 15 && t < 15.12) || (t >= 29 && t < 29.12) ? 5 : 0;
        const event = new Event('devicemotion');
        Object.defineProperties(event, {
          acceleration: {value: {x: ax, y: 0, z}},
          accelerationIncludingGravity: {value: {x: ax, y: 0, z: 9.80665 + z}},
          rotationRate: {value: {alpha: 0, beta: 0, gamma: 0}}, interval: {value: 20}
        });
        window.dispatchEvent(event);
      }
      index = last;
      return {samples: index + 1, meters, speed};
    }
  };
}

async function main() {
  let browser, context, page, video;
  const errors = [];
  const report = {status: 'running', synthetic: true, base_url: base,
    real_backend: true, sensor_hz: 50, scenario_seconds: 60,
    description: 'stationary calibration, gentle acceleration, 1 harsh start, 1 harsh brake, 2 moving vertical shocks, stop'};
  try {
    console.log(`Target: ${base}\nCreates a NEW guest and one synthetic trip. Existing browser accounts are not used.`);
    browser = await chromium.launch({headless: args.includes('--headless'),
      ...(process.env.CHROMIUM_PATH ? {executablePath: process.env.CHROMIUM_PATH} : {}),
      ...(process.platform === 'linux' ? {args: ['--no-sandbox']} : {})});
    context = await browser.newContext({viewport: {width: 414, height: 896},
      recordVideo: {dir: output, size: {width: 414, height: 896}}, serviceWorkers: 'block'});
    page = await context.newPage();
    video = page.video();
    page.setDefaultTimeout(30000);
    page.on('pageerror', error => errors.push(error.message));
    page.on('dialog', async dialog => {
      errors.push(`Unexpected dialog: ${dialog.message()}`);
      await dialog.dismiss();
    });
    await page.addInitScript(installSensors);
    // Inspect compatibility before creating any server-side demo data.
    const home = await page.request.get(base + '/');
    if (!home.ok() || !(await home.text()).includes('id="sum-smooth"')) {
      throw new Error('This address does not serve the product-epics UI. The ARS-6 ML-only branch 93a61f6 is not compatible. Use a copy of main with the normal trip UI.');
    }
    await page.goto(base + '/login');
    await pause(1800);
    await page.click('.btn-guest');
    await page.waitForURL(base + '/');
    await pause(2000);
    console.log('Guest session created. Selecting the vehicle through the garage.');
    await page.goto(base + '/setup?edit=1');
    await page.waitForFunction(() => document.querySelector('#select-make')?.options.length > 0);
    await page.selectOption('#select-make', {label: 'Haval'});
    await page.waitForFunction(() => [...document.querySelector('#select-trim').options].some(o => o.value === 'haval_jolion_15t_4wd'));
    await page.selectOption('#select-trim', 'haval_jolion_15t_4wd');
    await page.fill('#registry-fuel', '8.5');
    await pause(2000);
    // A normal UI button executes the existing save handler.
    await page.locator('[onclick="saveRegistryVehicle()"]:visible').click();
    await page.waitForSelector('#screen-garage-view.active');
    await pause(1800);
    await page.goto(base + '/');
    await page.waitForFunction(() => typeof requestStartTrip === 'function' && currentCityFuelRate === 8.5);
    await pause(1800);
    console.log('Recording a 60-second trip with 50 Hz IMU and 1 Hz GPS.');
    await page.click('[onclick="requestStartTrip()"]');
    await page.waitForFunction(() => tripActive);
    const wallStart = Date.now();
    for (let last = 0; last <= 3000; last += 5) {
      const due = wallStart + last * 20;
      if (due > Date.now()) await pause(due - Date.now());
      await page.evaluate(i => window.__autoXAKDemo.advance(i), last);
    }
    report.browser_capture = await page.evaluate(() => ({motion: motionSamples.length, gps: gpsSamples.length,
      moving_shocks: liveBumpsCount, distance_km: liveDistanceKm}));
    assert.equal(report.browser_capture.motion, 3001);
    assert.equal(report.browser_capture.gps, 61);
    assert(report.browser_capture.distance_km > .01);
    await page.screenshot({path: path.join(output, 'active-trip.png')});
    const thumb = page.locator('#swipe-thumb'), track = page.locator('#swipe-container');
    await thumb.scrollIntoViewIfNeeded();
    const a = await thumb.boundingBox(), b = await track.boundingBox();
    await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2);
    await page.mouse.down();
    for (let i = 1; i <= 25; i++) {
      await page.mouse.move(a.x + a.width / 2 + (b.x + b.width - a.width / 2 - 3 - a.x - a.width / 2) * i / 25, a.y + a.height / 2);
      await pause(25);
    }
    await page.mouse.up();
    await page.waitForSelector('#summary-modal.active');
    await page.waitForFunction(() => finishedResult && Number.isFinite(finishedResult.cost_savings_rub));
    report.result = await page.evaluate(() => ({session_id: finishedResult.session_id,
      cost_savings_rub: finishedResult.cost_savings_rub, distance_km: finishedResult.distance_km,
      harsh_accel_count: finishedResult.harsh_accel_count, harsh_brake_count: finishedResult.harsh_brake_count,
      road_anomalies_count: finishedResult.road_anomalies_count, smooth_score: finishedResult.smooth_score}));
    assert(report.result.cost_savings_rub > 0, 'Backend must calculate positive savings for this moving scenario');
    assert(report.result.harsh_accel_count >= 1 && report.result.harsh_brake_count >= 1, 'Maneuvers must be detected');
    assert.equal(report.result.road_anomalies_count, 2, 'The two moving shocks must be detected');
    await page.screenshot({path: path.join(output, 'trip-summary.png')});
    await pause(5500);
    const identity = await page.evaluate(() => ({user: AutoXAKSession.getUserId(), headers: AutoXAKSession.getAuthHeaders()}));
    const exportResponse = await page.request.get(`${base}/api/v2/trips/${report.result.session_id}/export`, {headers: identity.headers});
    assert(exportResponse.ok(), 'Saved raw recording must be exportable');
    const exported = await exportResponse.json();
    assert.equal(exported.point_counts.motion, 3001);
    assert.equal(exported.point_counts.gps, 61);
    fs.writeFileSync(path.join(output, 'telemetry.synthetic.json'), JSON.stringify(exported, null, 2));
    await page.click('[onclick="claimToPiggyBank()"]');
    await page.waitForFunction(() => !document.getElementById('summary-modal').classList.contains('active'));
    const dashboard = await page.request.get(`${base}/api/v1/users/${identity.user}/dashboard`, {headers: identity.headers});
    assert(dashboard.ok());
    const balance = await dashboard.json();
    assert.equal(balance.total_trips, 1, 'One demo must create exactly one trip');
    assert.equal(balance.total_savings_rub, report.result.cost_savings_rub, 'Balance must match the real calculation');
    await pause(3500);
    await page.goto(base + '/history');
    await page.waitForSelector('.trip-row-card');
    await pause(2500);
    await page.reload();
    await page.waitForSelector('.trip-row-card');
    report.history_survives_reload = true;
    await pause(1800);
    await page.locator('.btn-trip-details').first().click();
    await page.waitForSelector('#det-smooth:visible');
    await page.screenshot({path: path.join(output, 'history.png')});
    await pause(4500);
    assert.deepEqual(errors, [], 'No application errors or alerts expected');
    report.status = 'passed';
    report.balance_verified = true;
    console.log(`Backend result: ${JSON.stringify(report.result)}`);
  } catch (error) {
    report.status = 'failed'; report.error = error.message;
    if (page) await page.screenshot({path: path.join(output, 'failure.png')}).catch(() => {});
    throw error;
  } finally {
    report.browser_errors = errors;
    if (context) await context.close();
    if (video) {
      const file = path.join(output, report.status === 'passed' ? 'demo.webm' : 'partial-failed.webm');
      await video.saveAs(file);
      await video.delete();
      if (report.status === 'passed') {
        const conversion = spawnSync('ffmpeg', ['-y', '-i', file, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', path.join(output, 'demo.mp4')], {stdio: 'ignore'});
        report.mp4_created = conversion.status === 0;
      }
    }
    if (browser) await browser.close();
    fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
    console.log(`Output: ${output}`);
  }
}
main().catch(error => {console.error(error.message); process.exitCode = 1;});
