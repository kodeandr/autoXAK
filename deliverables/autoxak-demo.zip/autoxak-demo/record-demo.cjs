'use strict';
const {chromium} = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {spawnSync} = require('node:child_process');

const args = process.argv.slice(2);
function option(name, fallback) {
  const i = args.indexOf(name);
  if (i === -1) return fallback;
  if (!args[i + 1] || args[i + 1].startsWith('--')) throw new Error(`Value required for ${name}`);
  return args[i + 1];
}
const supplied = new URL(option('--url', 'http://localhost:8000'));
if (!['http:', 'https:'].includes(supplied.protocol) || supplied.username || supplied.password || supplied.search || supplied.hash || supplied.pathname !== '/') {
  throw new Error('Use only an HTTP(S) origin without credentials, query, or path.');
}
const base = supplied.origin;
const balanced = args.includes('--balanced');
const tour = balanced || args.includes('--tour');
const progress = tour || args.includes('--progress') || args.includes('--dynamic');
const short = progress || args.includes('--short');
const account = progress ? JSON.parse(fs.readFileSync(path.resolve(option('--account-file', path.join(__dirname, 'demo-account.private.json'))), 'utf8')) : null;
if (account && (account.base_url !== base || !account.prepared || !account.login || !account.password)) {
  throw new Error('Use a prepared private demo account file for this exact backend origin.');
}
const seconds = short ? 1200 : 60;
const motionCount = seconds * 50 + 1;
const output = path.join(__dirname, 'output', new Date().toISOString().replace(/[:.]/g, '-'));
fs.mkdirSync(output, {recursive: true});
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

// Only browser sensor inputs are synthetic. Application calculations, HTTP
// responses, balance, persistence and UI counters are never mocked or assigned.
function installSensors({longTrip}) {
  const realNow = Date.now.bind(Date);
  let clock = null, origin = null, index = -1, speed = 0, meters = 0;
  let nextWatch = 0;
  const watches = new Map();
  const transitions = [
    [4,0,14,1.25], [140,14,0,3.1], [170,0,14,2.7],
    [320,14,0,1.3], [355,0,14,1.2], [500,14,0,3],
    [540,0,14,2.8], [680,14,.7,1.4], [720,.7,14,1.1],
    [840,14,0,3.2], [890,0,14,2.9], [1030,14,0,1.4],
    [1075,0,14,1.3], [1178,14,0,2.8]
  ];
  const roadShocks = [[40,5],[110,5.5],[230,4.8],[410,5.8],[610,5.2],[800,4.9],[1125,5.4]];
  Date.now = () => clock === null ? realNow() : clock;
  const coords = () => ({latitude: 55.75 + meters / 111194.9266, longitude: 37.61,
    accuracy: 5, speed, altitude: null, altitudeAccuracy: null, heading: 0});
  Object.defineProperty(navigator, 'geolocation', {configurable: true, value: {
    watchPosition(callback) { const id = ++nextWatch; watches.set(id, callback); return id; },
    clearWatch(id) { watches.delete(id); },
    getCurrentPosition(callback) { callback({timestamp: Date.now(), coords: coords()}); }
  }});
  if (typeof DeviceMotionEvent !== 'undefined') Object.defineProperty(DeviceMotionEvent, 'requestPermission', {
    configurable: true, value: () => Promise.resolve('granted')
  });
  const badge = () => {
    if (document.getElementById('synthetic-demo-label')) return;
    const node = document.createElement('div');
    node.id = 'synthetic-demo-label';
    node.textContent = longTrip ? 'ДЕМО · синтетическая поездка · середина вырезана' : 'ДЕМО · синтетическая поездка';
    node.style.cssText = 'position:fixed;top:3px;right:5px;z-index:2147483647;font:9px sans-serif;color:#d2fa58;background:#121417e6;border-radius:3px;padding:3px 5px;pointer-events:none';
    document.body.append(node);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', badge); else badge();
  window.__autoXAKDemo = {
    prepare() { if (longTrip) { clock = realNow() - 1200000; origin = clock; } },
    advance(last) {
      if (origin === null) origin = realNow();
      for (let i = index + 1; i <= last; i++) {
        const t = i * .02;
        clock = origin + i * 20;
        // Finite 0.2-second ramps avoid instantaneous acceleration steps and
        // keep gentle braking safely away from the event threshold.
        const ramp = (start, end, peak, edge=.2) => t >= start && t < end
          ? peak * Math.min(1, (t - start) / edge, (end - t) / edge) : 0;
        const ax = longTrip
          ? transitions.reduce((sum,[start,from,to,peak]) => sum + ramp(start,
              start+Math.abs(to-from)/peak+.3, Math.sign(to-from)*peak, .3),0)
          : ramp(4, 10, 1.5) + ramp(20, 22, 3) + ramp(32, 34, -3)
            + ramp(40, 46, -1.5) + ramp(50, 54, 1.5) + ramp(54, 58, -1.5);
        if (i > 0) { speed = Math.max(0, speed + ax * .02); meters += speed * .02; }
        if (i % 50 === 0) for (const callback of watches.values()) callback({timestamp: clock, coords: coords()});
        const shock = longTrip ? roadShocks.find(([at]) => t >= at && t < at+.12) : null;
        const z = longTrip ? (shock ? shock[1] : 0) : ([15,29].some(at => t>=at && t<at+.12) ? 5 : 0);
        const event = new Event('devicemotion');
        Object.defineProperties(event, {
          acceleration: {value: {x: ax, y: 0, z}},
          accelerationIncludingGravity: {value: {x: ax, y: 0, z: 9.80665 + z}},
          rotationRate: {value: {alpha: 0, beta: 0, gamma: 0}}, interval: {value: 20}
        });
        window.dispatchEvent(event);
      }
      index = last;
      return {samples: index + 1, meters, speed};
    }
  };
}

async function main() {
  let browser, context, page, video;
  let recordingStart;
  const scenes = {};
  const mark = name => { scenes[name] = (Date.now() - recordingStart) / 1000; };
  const errors = [];
  let balanceBefore = {total_trips: 0, total_savings_rub: 0};
  const report = {status: 'running', synthetic: true, base_url: base,
    real_backend: true, sensor_hz: 50, scenario_seconds: seconds, short_edit: short, progress_demo: progress, tour_demo: tour, balanced_demo: balanced,
    description: short ? 'synthetic urban drive: varied acceleration/braking, traffic stops, slow queue and seven moving road shocks'
      : 'synthetic 60-second baseline trip'};
  try {
    if (short && spawnSync('ffmpeg', ['-version'], {stdio: 'ignore'}).status !== 0) {
      throw new Error('--short requires FFmpeg in PATH for the 20-second edit.');
    }
    console.log(`Target: ${base}\n${progress ? 'Logs into a prepared synthetic account and saves one new trip.' : 'Creates a NEW guest and one synthetic trip. Existing browser accounts are not used.'}`);
    browser = await chromium.launch({headless: args.includes('--headless'),
      ...(process.env.CHROMIUM_PATH ? {executablePath: process.env.CHROMIUM_PATH} : {}),
      ...(process.platform === 'linux' ? {args: ['--no-sandbox']} : {})});
    context = await browser.newContext({viewport: {width: 414, height: 896},
      recordVideo: {dir: output, size: {width: 414, height: 896}}, serviceWorkers: 'block'});
    recordingStart = Date.now();
    page = await context.newPage();
    video = page.video();
    page.setDefaultTimeout(30000);
    page.on('pageerror', error => errors.push(error.message));
    page.on('dialog', async dialog => {
      errors.push(`Unexpected dialog: ${dialog.message()}`);
      await dialog.dismiss();
    });
    await page.addInitScript(installSensors, {longTrip: short});
    // Inspect compatibility before creating any server-side demo data.
    const home = await page.request.get(base + '/');
    if (!home.ok() || !(await home.text()).includes('id="sum-smooth"')) {
      throw new Error('This address does not serve the product-epics UI. The ARS-6 ML-only branch 93a61f6 is not compatible. Use a copy of main with the normal trip UI.');
    }
    await page.goto(base + '/login');
    if (progress) {
      await page.getByRole('button', {name: 'Войти', exact: true}).click();
      mark('login');
      await page.locator('#auth-login').pressSequentially(account.login, {delay: 90});
      await page.locator('#auth-password').pressSequentially(account.password, {delay: 90});
      await pause(650);
      mark('loginSubmitted');
      await page.click('#auth-submit');
    } else {
      await pause(1800);
      await page.click('.btn-guest');
    }
    await page.waitForURL(base + '/');
    await pause(2000);
    if (progress) {
      const identity = await page.evaluate(() => ({user: AutoXAKSession.getUserId(), headers: AutoXAKSession.getAuthHeaders()}));
      assert.equal(identity.user, account.user_id);
      balanceBefore = await (await page.request.get(`${base}/api/v1/users/${identity.user}/dashboard`, {headers: identity.headers})).json();
      report.balance_before = balanceBefore.total_savings_rub;
      report.existing_trips = balanceBefore.total_trips;
      report.progress_before = await (await page.request.get(`${base}/api/v1/users/${identity.user}/progress?days=7&utc_offset_minutes=0`, {headers: identity.headers})).json();
      assert(report.existing_trips >= 59 && report.progress_before.sufficient_data);
    }
    if (tour) {
      await page.click('a[aria-label="История поездок"]');
      await page.waitForSelector('.trip-row-card');
      await page.waitForSelector('#history-progress .progress-chart circle');
      mark('introHistory');
      await pause(balanced ? 800 : 450);
      mark('introPeriodSwitch');
      await page.click('[data-days="30"]');
      await page.waitForFunction(() => document.querySelectorAll('#history-progress .progress-chart circle').length>=29);
      await pause(balanced ? 950 : 550);
      mark('introHistoryScroll');
      await page.mouse.wheel(0,320);
      await pause(balanced ? 1300 : 1100);
      await page.screenshot({path:path.join(output,'intro-history.png')});
      await page.click('a[aria-label="Мой автомобиль"]');
      await page.waitForSelector('#screen-garage-view.active');
      mark('garageOpen');
      await pause(balanced ? 600 : 450);
      await page.click('[onclick="openEditScreen()"]');
      await page.waitForSelector('#screen-garage-edit.active');
    } else await page.goto(base + '/setup?edit=1');
    console.log('Authenticated session ready. Selecting the vehicle through the garage.');
    await page.waitForFunction(() => document.querySelector('#select-make')?.options.length > 0);
    if(tour) {
      mark('garageChoice');
      await page.selectOption('#select-make',{label:'Geely'});
      await pause(balanced ? 680 : 550);
      // Native input: open the brand picker, then use the actual select value.
      await page.click('#select-make');
      await pause(balanced ? 680 : 550);
      await page.keyboard.press('Escape');
    }
    await page.selectOption('#select-make', {label: 'Haval'});
    await page.waitForFunction(() => [...document.querySelector('#select-trim').options].some(o => o.value === 'haval_jolion_15t_4wd'));
    if(tour) {
      await pause(balanced ? 680 : 550);
      await page.click('#select-model');
      await pause(balanced ? 650 : 450);
      await page.keyboard.press('Escape');
      await page.selectOption('#select-trim','haval_jolion_15t_fwd');
      await pause(balanced ? 680 : 550);
      await page.click('#select-trim');
      await pause(balanced ? 680 : 550);
      await page.keyboard.press('Escape');
    }
    await page.selectOption('#select-trim', 'haval_jolion_15t_4wd');
    await page.fill('#registry-fuel', '8.5');
    await pause(balanced ? 680 : tour ? 550 : 2000);
    // A normal UI button executes the existing save handler.
    await page.locator('[onclick="saveRegistryVehicle()"]:visible').click();
    await page.waitForSelector('#screen-garage-view.active');
    if(tour) {
      mark('garageSaved');
      await pause(balanced ? 900 : 600);
      await page.click('a[aria-label="Главный экран"]');
    } else {
      await pause(1800);
      await page.goto(base + '/');
    }
    await page.waitForFunction(() => typeof requestStartTrip === 'function' && currentCityFuelRate === 8.5);
    mark('home');
    await pause(balanced ? 1600 : tour ? 1000 : short ? 3500 : 1800);
    console.log(`Recording a ${seconds}-second synthetic trip with 50 Hz IMU and 1 Hz GPS.`);
    await page.evaluate(() => window.__autoXAKDemo.prepare());
    mark('startRequest');
    await page.click('[onclick="requestStartTrip()"]');
    await page.waitForFunction(() => tripActive);
    mark('start');
    const wallStart = Date.now();
    const realTimeEnd = balanced ? 1250 : tour ? 750 : short ? 400 : 3000;
    for (let last = 0; last <= realTimeEnd; last += 5) {
      const due = wallStart + last * 20;
      if (due > Date.now()) await pause(due - Date.now());
      await page.evaluate(i => window.__autoXAKDemo.advance(i), last);
      if(tour && last===450) {
        mark('moving');
        report.first_moving_distance_km=await page.evaluate(()=>liveDistanceKm);
        assert(report.first_moving_distance_km>.005,'Moving footage must have real accumulated meters');
      }
      if(balanced && last%50===0 && !report.first_positive_preview) {
        const shown=await page.evaluate(()=>({
          rubles:Number(document.getElementById('trip-live-savings').textContent.replace(/[^0-9.,-]/g,'').replace(',','.')),
          distance_km:liveDistanceKm,elapsed_s:(Date.now()-tripStartTime)/1000
        }));
        if(shown.rubles>0) {
          mark('firstPositivePreview');report.first_positive_preview=shown;
        }
      }
    }
    if(balanced) assert(report.first_positive_preview?.rubles>0,'Natural backend preview must be positive before the selected moving scene');
    if (short) {
      for (let last = realTimeEnd+500; last < motionCount; last = Math.min(last + 500, motionCount - 1)) {
        await page.evaluate(i => window.__autoXAKDemo.advance(i), last);
        if (last === motionCount - 1) break;
        await pause(20);
      }
      await pause(1200); // Let the existing HUD timer and preview render.
      mark('end');
      await pause(2500);
    }
    report.browser_capture = await page.evaluate(() => ({motion: motionSamples.length, gps: gpsSamples.length,
      moving_shocks: liveBumpsCount, distance_km: liveDistanceKm}));
    assert.equal(report.browser_capture.motion, motionCount);
    assert.equal(report.browser_capture.gps, seconds + 1);
    assert(report.browser_capture.distance_km > .01);
    await page.screenshot({path: path.join(output, 'active-trip.png')});
    const thumb = page.locator('#swipe-thumb'), track = page.locator('#swipe-container');
    await thumb.scrollIntoViewIfNeeded();
    const a = await thumb.boundingBox(), b = await track.boundingBox();
    mark('swipe');
    await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2);
    await page.mouse.down();
    for (let i = 1; i <= 25; i++) {
      await page.mouse.move(a.x + a.width / 2 + (b.x + b.width - a.width / 2 - 3 - a.x - a.width / 2) * i / 25, a.y + a.height / 2);
      await pause(25);
    }
    mark('swipeReleased');
    await page.mouse.up();
    await page.waitForSelector('#summary-modal.active');
    await page.waitForFunction(() => finishedResult && Number.isFinite(finishedResult.cost_savings_rub));
    mark('summary');
    report.result = await page.evaluate(() => ({session_id: finishedResult.session_id,
      cost_savings_rub: finishedResult.cost_savings_rub, distance_km: finishedResult.distance_km,
      harsh_accel_count: finishedResult.harsh_accel_count, harsh_brake_count: finishedResult.harsh_brake_count,
      road_anomalies_count: finishedResult.road_anomalies_count, smooth_score: finishedResult.smooth_score,
      duration_seconds: finishedResult.duration_seconds, traffic_jam_seconds: finishedResult.traffic_jam_seconds}));
    if (short) assert(report.result.distance_km >= 10 && report.result.distance_km <= 15, 'Saved trip must be 10–15 km');
    assert(report.result.cost_savings_rub > 0, 'Backend must calculate positive savings for this moving scenario');
    assert(report.result.harsh_accel_count >= 1 && report.result.harsh_brake_count >= 1, 'Maneuvers must be detected');
    assert.equal(report.result.road_anomalies_count, short ? 7 : 2, 'The generated moving shocks must be detected');
    if (short) {
      assert(report.result.harsh_accel_count>=3 && report.result.harsh_brake_count>=4);
      assert(report.result.traffic_jam_seconds>=120 && report.result.smooth_score<100);
    }
    await page.screenshot({path: path.join(output, 'trip-summary.png')});
    await pause(short ? 6500 : 5500);
    const identity = await page.evaluate(() => ({user: AutoXAKSession.getUserId(), headers: AutoXAKSession.getAuthHeaders()}));
    const exportResponse = await page.request.get(`${base}/api/v2/trips/${report.result.session_id}/export`, {headers: identity.headers});
    assert(exportResponse.ok(), 'Saved raw recording must be exportable');
    const exported = await exportResponse.json();
    assert.equal(exported.point_counts.motion, motionCount);
    assert.equal(exported.point_counts.gps, seconds + 1);
    fs.writeFileSync(path.join(output, 'telemetry.synthetic.json'), JSON.stringify(exported, null, 2));
    mark('claim');
    await page.click('[onclick="claimToPiggyBank()"]');
    await page.waitForFunction(() => !document.getElementById('summary-modal').classList.contains('active'));
    const dashboard = await page.request.get(`${base}/api/v1/users/${identity.user}/dashboard`, {headers: identity.headers});
    assert(dashboard.ok());
    const balance = await dashboard.json();
    assert.equal(balance.total_trips, balanceBefore.total_trips + 1, 'One demo must create exactly one new trip');
    assert(Math.abs(balance.total_savings_rub - balanceBefore.total_savings_rub - report.result.cost_savings_rub) < .011, 'Balance must increase by the real calculation');
    report.balance_after = balance.total_savings_rub;
    await page.waitForFunction(() => !claiming);
    mark('balance');
    await pause(short ? 2500 : 3500);
    await page.goto(base + '/history');
    await page.waitForSelector('.trip-row-card');
    await pause(2500);
    await page.reload();
    await page.waitForSelector('.trip-row-card');
    report.history_survives_reload = true;
    await pause(1800);
    if (progress) {
      const identity = await page.evaluate(() => ({user: AutoXAKSession.getUserId(), headers: AutoXAKSession.getAuthHeaders()}));
      report.progress_after = {};
      for (const days of [7, 30]) {
        const response = page.waitForResponse(r => r.url().includes('/progress?days=' + days + '&') && r.status() === 200);
        mark('graph' + days + 'Requested');
        await page.click(`[data-days="${days}"]`);
        const data = await (await response).json();
        assert(data.sufficient_data && Number.isFinite(data.delta));
        await page.waitForFunction(count => document.querySelectorAll('#history-progress .progress-chart circle').length === count,
          data.points.filter(p => Number.isFinite(p.score)).length);
        assert.equal(await page.locator('#history-progress .progress-number').innerText(), String(data.average));
        report.progress_after[days] = data;
        mark('graph' + days);
        await page.screenshot({path: path.join(output, `progress-${days}.png`)});
        if(tour && days===7) {
          await pause(1300);
          mark('finalHistoryScroll');
          await page.mouse.wheel(0,300);
          await pause(1100);
          await page.screenshot({path:path.join(output,'final-history-list.png')});
          await page.mouse.wheel(0,-300);
          await pause(250);
        } else await pause(3500);
      }
    } else {
      await page.locator('.btn-trip-details').first().click();
      await page.waitForSelector('#det-smooth:visible');
      mark('history');
      await page.screenshot({path: path.join(output, 'history.png')});
      await pause(4500);
    }
    assert.deepEqual(errors, [], 'No application errors or alerts expected');
    report.status = 'passed';
    report.balance_verified = true;
    console.log(`Backend result: ${JSON.stringify(report.result)}`);
  } catch (error) {
    report.status = 'failed'; report.error = error.message;
    if (page) await page.screenshot({path: path.join(output, 'failure.png')}).catch(() => {});
    throw error;
  } finally {
    report.browser_errors = errors;
    if (context) await context.close();
    if (video) {
      const file = path.join(output, report.status === 'passed' ? 'demo.webm' : 'partial-failed.webm');
      await video.saveAs(file);
      await video.delete();
      if (report.status === 'passed') {
        const conversion = spawnSync('ffmpeg', ['-y', '-i', file, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', path.join(output, 'demo.mp4')], {stdio: 'ignore'});
        report.mp4_created = conversion.status === 0;
        if (short) {
          const clips = progress
            ? [[scenes.login, 4], [scenes.home + 1.5, 2], [scenes.end, 2], [scenes.swipe, 1],
              [scenes.summary, 4], [scenes.balance, 1], [scenes.graph7, 3], [scenes.graph30, 3]]
            : [[scenes.home, 3], [scenes.start + 3, 3], [scenes.end, 2],
              [scenes.swipe, 1], [scenes.summary, 6], [scenes.balance, 2], [scenes.history, 3]];
          const filters = clips.map(([start, duration], i) => `[0:v]trim=start=${start.toFixed(3)}:duration=${duration},setpts=PTS-STARTPTS,fps=30[v${i}]`);
          filters.push(clips.map((_,i) => `[v${i}]`).join('') + `concat=n=${clips.length}:v=1:a=0,format=yuv420p[out]`);
          const edited = spawnSync('ffmpeg', ['-y', '-i', file, '-filter_complex', filters.join(';'),
            '-map', '[out]', '-t', '20', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
            path.join(output, progress ? 'demo-progress-20s.mp4' : 'demo-20s.mp4')], {stdio: 'ignore'});
          report.short_edit_created = edited.status === 0;
          report.edit_segments = clips;
          if (!report.short_edit_created) { report.status = 'failed'; process.exitCode = 1; }
        }
      }
    }
    if (browser) await browser.close();
    report.scenes = scenes;
    report.capture_status = report.status;
    fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
    if ((tour || args.includes('--dynamic')) && report.status === 'passed') {
      const edited = spawnSync(process.execPath, [path.join(__dirname, balanced ? 'edit-balanced.cjs' : tour ? 'edit-tour.cjs' : 'edit-dynamic.cjs'), output], {stdio: 'inherit'});
      report.dynamic_edit_created = edited.status === 0;
      if (!report.dynamic_edit_created) { report.status = 'failed'; process.exitCode = 1; }
      fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
    }
    console.log(`Output: ${output}`);
  }
}
main().catch(error => {console.error(error.message); process.exitCode = 1;});
