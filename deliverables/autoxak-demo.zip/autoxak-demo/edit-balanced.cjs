'use strict';
const fs=require('node:fs'), path=require('node:path');
const {spawnSync}=require('node:child_process');
const assert=require('node:assert/strict');
const folder=path.resolve(process.argv[2]||'.');
const report=JSON.parse(fs.readFileSync(path.join(folder,'report.json'),'utf8'));
const capturePassed=report.status==='passed' || (report.balance_verified && report.history_survives_reload &&
 report.result && report.browser_errors?.length===0 && report.dynamic_edit_created===false);
assert(capturePassed && report.tour_demo && report.balanced_demo,'A successful --balanced browser capture is required.');
const s=report.scenes;
for(const k of ['login','loginSubmitted','introHistory','introHistoryScroll','garageOpen','garageSaved',
 'startRequest','start','moving','firstPositivePreview','swipe','swipeReleased','summary','claim','balance','graph7','finalHistoryScroll']) {
 assert(Number.isFinite(s[k]),'Missing '+k+' marker');
}
assert(report.first_moving_distance_km>.005 && report.first_positive_preview?.rubles>0);
const font=[process.env.DEMO_FONT_PATH,
 process.platform==='win32'?path.join(process.env.WINDIR||'C:/Windows','Fonts','segoeui.ttf'):'',
 '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/System/Library/Fonts/Supplemental/Arial.ttf']
 .filter(Boolean).find(p=>fs.existsSync(p));
assert(font,'Set DEMO_FONT_PATH to a Cyrillic-capable font.');
const escaped=font.replace(/\\/g,'/').replace(/:/g,'\\:').replace(/'/g,"'\\''");
const duration=25;
const garageLength=s.garageSaved+.75-s.garageOpen;
const claimLength=s.balance+.2-(s.claim-.3);
const clips=[
 {name:'typed_login_and_password',start:s.login,length:s.loginSubmitted+.6-s.login,speed:1},
 {name:'history_period_switch_and_scroll',start:s.introHistory,length:s.introHistoryScroll+1.15-s.introHistory,speed:1},
 {name:'garage_make_model_trim_and_save',start:s.garageOpen,length:garageLength,speed:Math.max(1,garageLength/6)},
 {name:'start_button_and_initial_hud',start:s.startRequest-.95,length:s.start+.6-(s.startRequest-.95),speed:1},
 {name:'positive_preview_and_growing_meters',start:s.firstPositivePreview+.1,length:2.4,speed:1},
 {name:'trip_end_and_complete_swipe',start:s.swipe-1.2,length:s.swipeReleased+.04-(s.swipe-1.2),speed:1},
 {name:'calculated_trip_result',start:s.summary+.05,length:3.4,speed:1},
 {name:'claim_savings',start:s.claim-.3,length:claimLength,speed:Math.max(1,claimLength/1.1)},
 {name:'updated_dashboard',start:s.balance+.2,length:1.3,speed:1},
 {name:'updated_graph_and_latest_trips',start:s.graph7,length:s.finalHistoryScroll+1-s.graph7,speed:1}
];
const fades=[.12,.12,.12,.16,.24,.16,0,0,.12];
const content=()=>clips.reduce((sum,c)=>sum+c.length/c.speed,0)-fades.reduce((a,b)=>a+b,0);
clips[4].length+=duration-content();
if(clips[4].length>3.2) {
 const extra=clips[4].length-3.2;
 assert(extra<.9,'Intro footage is too short for this edit.');
 clips[6].length+=extra;clips[4].length=3.2;
}
assert(clips[4].length>=1.7 && clips[4].length<=3.2,'Moving footage must be long enough and remain within the captured moving segment.');
const filters=clips.map((c,i)=>`[0:v]trim=start=${c.start.toFixed(6)}:duration=${c.length.toFixed(6)},`+
 `setpts=(PTS-STARTPTS)/${c.speed.toFixed(6)},fps=30,setsar=1,settb=AVTB,format=yuv420p[v${i}]`);
let previous='v0', elapsed=clips[0].length/clips[0].speed;
for(let i=1;i<clips.length;i++) {
 const label='j'+i,f=fades[i-1];
 if(f)filters.push(`[${previous}][v${i}]xfade=transition=fade:duration=${f}:offset=${(elapsed-f).toFixed(6)}[${label}]`);
 else filters.push(`[${previous}][v${i}]concat=n=2:v=1:a=0,settb=AVTB[${label}]`);
 elapsed+=clips[i].length/clips[i].speed-f;previous=label;
}
filters.push(`[${previous}]tpad=stop_mode=clone:stop_duration=0.15,trim=duration=${duration},`+
 `drawbox=x=6:y=4:w=iw-12:h=14:color=0x121417:t=fill,`+
 `drawtext=fontfile='${escaped}':text='ДЕМО · синтетические данные · монтаж':fontsize=9:fontcolor=0xD2FA58:x=w-tw-7:y=6,format=yuv420p[out]`);
const output=path.join(folder,'demo-app-balanced-25s.mp4');
const result=spawnSync(process.env.FFMPEG_PATH||'ffmpeg',['-v','error','-y','-i',path.join(folder,'demo.webm'),
 '-filter_complex',filters.join(';'),'-map','[out]','-r','30','-t','25','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',output],{encoding:'utf8'});
if(result.status!==0)throw new Error(result.stderr||'FFmpeg failed');
fs.writeFileSync(path.join(folder,'balanced-edit-report.json'),JSON.stringify({duration_seconds:duration,synthetic:true,
 clips,transitions_seconds:fades,static_final_hold_removed:true,moving_distance_km_at_capture:report.first_moving_distance_km,first_positive_preview:report.first_positive_preview,
 result:report.result,balance_before:report.balance_before,balance_after:report.balance_after,
 existing_trips:report.existing_trips,progress_after:report.progress_after},null,2));
console.log(output);console.log(JSON.stringify({content_duration:elapsed,moving_seconds:clips[4].length}));
