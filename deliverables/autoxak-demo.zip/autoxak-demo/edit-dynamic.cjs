'use strict';
// A video-only edit: shorten waits while preserving actions and calculated UI.
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const assert = require('node:assert/strict');
const folder = path.resolve(process.argv[2] || '.');
const report = JSON.parse(fs.readFileSync(path.join(folder, 'report.json'), 'utf8'));
assert(report.status === 'passed' && report.progress_demo && report.scenes, 'A new successful Progress recording with scene markers is required.');
const s = report.scenes;
for (const key of ['login','loginSubmitted','start','end','swipe','swipeReleased','summary','claim','balance','graph7','graph30Requested','graph30']) {
  assert(Number.isFinite(s[key]), `Missing ${key} marker`);
}
const font = [process.env.DEMO_FONT_PATH,
  process.platform === 'win32' ? path.join(process.env.WINDIR || 'C:/Windows','Fonts','segoeui.ttf') : '',
  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/System/Library/Fonts/Supplemental/Arial.ttf']
  .filter(Boolean).find(p => fs.existsSync(p));
assert(font, 'Set DEMO_FONT_PATH to a font with Cyrillic support.');
const escapedFont = font.replace(/\\/g,'/').replace(/:/g,'\\:').replace(/'/g,"'\\''");
const source = path.join(folder,'demo.webm');
const duration = 25;
const claimDuration = s.balance + .2 - (s.claim - .3);
const clips = [
  {name:'login_and_password_typing', start:s.login, length:s.loginSubmitted+.6-s.login, speed:1},
  {name:'home_start_and_first_seconds', start:s.start-1.6, length:9.4, speed:1.25},
  {name:'trip_end_and_full_swipe', start:s.swipe-1.5, length:s.swipeReleased+.04-(s.swipe-1.5), speed:1},
  {name:'server_calculated_summary', start:s.summary+.05, length:3.5, speed:1},
  {name:'claim_and_dashboard', start:s.claim-.3, length:claimDuration, speed:Math.max(1,claimDuration/1.1)},
  {name:'updated_balance_and_progress', start:s.balance+.2, length:1.5, speed:1},
  {name:'seven_day_graph', start:s.graph7, length:3, speed:1},
  {name:'switch_to_thirty_day_graph', start:s.graph30Requested-.2, length:3.7, speed:1}
];
const fades=[.12,.28,.16,0,0,.12,0];
const totalBeforeTrim=clips.reduce((sum,c)=>sum+c.length/c.speed,0)-fades.reduce((a,b)=>a+b,0);
if(totalBeforeTrim>duration) clips[clips.length-1].length-=totalBeforeTrim-duration;
assert(clips[clips.length-1].length>=2.5, 'Keep at least 2.5 seconds for the final graph.');
const filters=clips.map((c,i)=>`[0:v]trim=start=${c.start.toFixed(6)}:duration=${c.length.toFixed(6)},`+
  `setpts=(PTS-STARTPTS)/${c.speed.toFixed(6)},fps=30,setsar=1,settb=AVTB,format=yuv420p[v${i}]`);
let accumulated=clips[0].length/clips[0].speed;
let previous='v0';
for(let i=1;i<clips.length;i++) {
  const label='join'+i, fade=fades[i-1];
  if(fade) filters.push(`[${previous}][v${i}]xfade=transition=fade:duration=${fade}:offset=${(accumulated-fade).toFixed(6)}[${label}]`);
  else filters.push(`[${previous}][v${i}]concat=n=2:v=1:a=0,settb=AVTB[${label}]`);
  accumulated+=clips[i].length/clips[i].speed-fade;
  previous=label;
}
assert(accumulated<duration+.5 && accumulated>duration-2, 'Edit duration must preserve all scenes within the target.');
filters.push(`[${previous}]tpad=stop_mode=clone:stop_duration=2,trim=duration=${duration},`+
  `drawbox=x=6:y=4:w=iw-12:h=14:color=0x121417:t=fill,`+
  `drawtext=fontfile='${escapedFont}':text='ДЕМО · синтетические данные · монтаж':fontsize=9:fontcolor=0xD2FA58:x=w-tw-7:y=6,format=yuv420p[out]`);
const output=path.join(folder,'demo-progress-dynamic-25s.mp4');
const result=spawnSync(process.env.FFMPEG_PATH||'ffmpeg',['-v','error','-y','-i',source,'-filter_complex',filters.join(';'),
  '-map','[out]','-r','30','-t',String(duration),'-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',output],{encoding:'utf8'});
if(result.status!==0)throw new Error(result.stderr||'FFmpeg failed');
fs.writeFileSync(path.join(folder,'dynamic-edit-report.json'),JSON.stringify({duration_seconds:duration,synthetic:true,
  editing_only:true,processing_waits_omitted:true,all_scenes_preserved:true,clips,transitions_seconds:fades,
  source_balance_before:report.balance_before,source_balance_after:report.balance_after,
  source_existing_trips:report.existing_trips,source_result:report.result,progress_after:report.progress_after},null,2));
console.log(output);
console.log(JSON.stringify({content_duration:accumulated,output_duration:duration}));
