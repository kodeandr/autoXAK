param(
    [string]$Url = 'http://localhost:8000',
    [switch]$Headless
)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        throw 'Install Node.js 22 LTS from https://nodejs.org, then reopen PowerShell.'
    }
    $demoNodeMajor = & node -p 'parseInt(process.versions.node)'
    if ($LASTEXITCODE -ne 0) { throw 'Cannot determine Node.js version.' }
    if ([int]$demoNodeMajor -lt 20) {
        throw 'Node.js 20+ is required; Node.js 22 LTS is recommended.'
    }
    & npm.cmd ci --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw 'npm ci failed.' }
    & npx.cmd playwright install chromium
    if ($LASTEXITCODE -ne 0) { throw 'Chromium installation failed.' }
    $demoArgs = @('record-demo.cjs', '--url', $Url)
    if ($Headless) { $demoArgs += '--headless' }
    & node @demoArgs
    if ($LASTEXITCODE -ne 0) { throw 'Demo failed. Read the error and output report.' }
}
finally { Pop-Location }
