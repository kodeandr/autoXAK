'use strict';
// Re-edit an existing progress demo. No server calls or application changes.
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const assert = require('node:assert/strict');

const folder = path.resolve(process.argv[2] || '.');
const report = JSON.parse(fs.readFileSync(path.join(folder, 'report.json'), 'utf8'));
assert(report.status === 'passed' && report.progress_demo && report.edit_segments.length === 8,
  'Use the output folder of a successful --progress recording.');
const input = path.join(folder, 'demo.webm');
assert(fs.existsSync(input), 'The original demo.webm recording is required.');
const ffmpeg = process.env.FFMPEG_PATH || 'ffmpeg';
const fonts = [process.env.DEMO_FONT_PATH,
  process.platform === 'win32' ? path.join(process.env.WINDIR || 'C:/Windows', 'Fonts', 'segoeui.ttf') : '',
  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/System/Library/Fonts/Supplemental/Arial.ttf'].filter(Boolean);
const font = fonts.find(p => fs.existsSync(p));
if (!font) throw new Error('Set DEMO_FONT_PATH to a font file with Cyrillic support.');
const escape = s => s.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "'\\''");
const old = report.edit_segments;
const duration = 32, dissolve = .3;
const finish = [old[2][0], old[4][0] + old[4][1] - old[2][0]];
const fixedDuration = old[0][1] + finish[1] + old[5][1] + old[6][1] + old[7][1];
const start = [old[1][0], duration + dissolve - fixedDuration];
assert(start[1] > old[1][1] && start[0] + start[1] < finish[0], 'Enough original starting footage must exist.');
const clips = [old[0], start, finish, old[5], old[6], old[7]];
const filters = clips.map(([at, length], i) =>
  `[0:v]trim=start=${at.toFixed(6)}:duration=${length.toFixed(6)},setpts=PTS-STARTPTS,fps=30,setsar=1,settb=AVTB,format=yuv420p[v${i}]`);
filters.push('[v0][v1]concat=n=2:v=1:a=0,settb=AVTB[opening]');
filters.push(`[opening][v2]xfade=transition=fade:duration=${dissolve}:offset=${(old[0][1]+start[1]-dissolve).toFixed(6)}[trip]`);
filters.push('[trip][v3][v4][v5]concat=n=4:v=1:a=0[assembled]');
// Replace only the old editorial badge (which said "20 s"). Keep the app
// interface and real calculated figures intact, including the glow border.
filters.push(`[assembled]tpad=stop_mode=clone:stop_duration=1,trim=duration=${duration},` +
  `drawbox=x=6:y=4:w=iw-12:h=14:color=0x121417:t=fill,` +
  `drawtext=fontfile='${escape(font)}':text='ДЕМО · синтетическая поездка · середина вырезана':` +
  'fontsize=9:fontcolor=0xD2FA58:x=w-tw-7:y=6,format=yuv420p[out]');
const output = path.join(folder, 'demo-progress-smooth-32s.mp4');
const result = spawnSync(ffmpeg, ['-v', 'error', '-y', '-i', input, '-filter_complex', filters.join(';'),
  '-map', '[out]', '-r', '30', '-t', String(duration), '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
  '-movflags', '+faststart', output], {encoding: 'utf8'});
if (result.status !== 0) throw new Error(result.stderr || 'FFmpeg failed');
const editReport = {synthetic: true, duration_seconds: duration, source: 'demo.webm', source_segments: clips,
  continuous_start: {start: start[0], duration: start[1]}, continuous_finish: {start: finish[0], duration: finish[1]},
  middle_transition_seconds: dissolve, login_summary_balance_graph_durations_preserved: true,
  original_result: report.result, existing_trips: report.existing_trips,
  progress_after: report.progress_after};
fs.writeFileSync(path.join(folder, 'smooth-edit-report.json'), JSON.stringify(editReport, null, 2));
console.log(output);
console.log(JSON.stringify({duration_seconds: duration, start_seconds: start[1], finish_seconds: finish[1]}));
