'use strict';
// Synthetic history is submitted through the normal API; no SQL score writes,
// fake API responses or balance assignments are used.
const fs = require('node:fs');
const path = require('node:path');
const {randomBytes, randomUUID} = require('node:crypto');
const assert = require('node:assert/strict');
const argv = process.argv.slice(2);
const i = argv.indexOf('--url');
const parsed = new URL(i < 0 ? 'http://localhost:8000' : argv[i + 1]);
if (!['http:', 'https:'].includes(parsed.protocol) || !['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname)
    || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) {
  throw new Error('History preparation requires an explicit local demo backend origin.');
}
const base = parsed.origin;
const accountPath = path.join(__dirname, 'demo-account.private.json');
if (fs.existsSync(accountPath)) throw new Error('demo-account.private.json already exists. Keep it for recording or move it before preparing another account.');
async function api(route, {body, method, token} = {}) {
  const response = await fetch(base + route, {method: method || (body ? 'POST' : 'GET'),
    headers: {'Content-Type': 'application/json', ...(token ? {Authorization: 'Bearer ' + token} : {})},
    ...(body ? {body: JSON.stringify(body)} : {}), signal: AbortSignal.timeout(60000)});
  if (!response.ok) throw new Error(`HTTP ${response.status} for ${route}`);
  return response.json();
}
function trip(userId, age) {
  const date = new Date(); date.setUTCHours(12, 0, 0, 0); date.setUTCDate(date.getUTCDate() - age);
  const origin = date.getTime(), stream = [], motion = [], gps = [];
  const duration = .9 + age * .027;
  let speed = 0, meters = 0, lat = 55.75;
  const ramp = (t, start, end, peak) => t >= start && t < end ? peak * Math.min(1, (t-start)/.2, (end-t)/.2) : 0;
  for (let n = 0; n <= 60000; n++) {
    const t = n * .02, timestamp = origin + n * 20;
    let ax = ramp(t, 4, 12.2, 1) + ramp(t, 1175, 1183.2, -1);
    // Base speed ~29 km/h, with finite aggressive cycles up to ~54 km/h.
    // Longer episodes on older days produce the historical progression.
    const start = 20 + Math.floor((t - 20) / 12) * 12;
    if (start >= 20 && start < 1170) ax += ramp(t, start, start + duration, 3)
      + ramp(t, start + 6, start + 6 + duration, -3);
    if (n) { speed = Math.max(0, speed + ax * .02); meters += speed * .02; }
    if (n % 50 === 0) {
      lat = 55.75 + meters / 111194.9266;
      gps.push({timestamp_ms: timestamp, latitude: lat, longitude: 37.61, accuracy_m: 5, speed_mps: speed, speed_source: 'gps'});
    }
    stream.push({t: timestamp / 1000, ax, ay: 0, az: 9.80665, gx: 0, gy: 0, gz: 0, speed, lat, lon: 37.61});
    motion.push({timestamp_ms: timestamp, ax, ay: 0, az: 0, gx: 0, gy: 0, gz: 0,
      acceleration_includes_gravity: false, interval_ms: 20});
  }
  return {session_id: randomUUID(), user_id: userId, car_id: 'haval_jolion_15t_4wd', telemetry_stream: stream,
    raw_recording: {started_at_ms: origin, ended_at_ms: origin + 1200000, gps, motion,
      permissions: {motion: 'granted', geolocation: 'granted'}, end_reason: 'user',
      device: {app_version: 'synthetic-demo-history-2', placement: 'Synthetic 20-minute city fixture; not a road recording'}}};
}
(async () => {
  const loginAt = argv.indexOf('--login');
  const login = loginAt < 0 ? 'demouser' : argv[loginAt + 1];
  const password = 'Dm!' + randomBytes(5).toString('hex');
  const session = await api('/api/v1/auth/register', {body: {login, password}});
  const token = session.token, user = session.user_id;
  const account = {base_url: base, login, password, user_id: user, synthetic: true, prepared: false};
  fs.writeFileSync(accountPath, JSON.stringify(account, null, 2), {mode: 0o600, flag: 'wx'});
  await api(`/api/v1/users/${user}/profile`, {token, method: 'POST', body: {
    car_id: 'haval_jolion_15t_4wd', car_name: 'Haval Jolion 1.5T 4WD', fuel_consumption: 8.5}});
  const results = [];
  for (let age = 59; age >= 1; age--) {
    const result = await api('/api/v1/telemetry/session', {token, body: trip(user, age)});
    assert(Number.isFinite(result.smooth_score));
    assert(result.distance_km >= 10 && result.distance_km <= 15);
    assert.equal(result.duration_seconds, 1200);
    results.push({age_days: age, session_id: result.session_id, score: result.smooth_score,
      rubles: result.cost_savings_rub, distance_km: result.distance_km, duration_seconds: result.duration_seconds,
      motion_points: 60001, gps_points: 1201});
    if (age % 10 === 0 || age === 1) console.log(`History: ${60-age}/59 trips calculated and saved`);
  }
  const periods = {};
  for (const days of [7, 30]) {
    periods[days] = await api(`/api/v1/users/${user}/progress?days=${days}&utc_offset_minutes=0`, {token});
    assert(periods[days].sufficient_data && Number.isFinite(periods[days].delta));
    assert(periods[days].delta > 0);
  }
  account.prepared = true;
  fs.writeFileSync(accountPath, JSON.stringify(account, null, 2), {mode: 0o600});
  fs.writeFileSync(path.join(__dirname, 'history-preparation-report.json'), JSON.stringify({synthetic: true,
    user_id: user, trips: results, periods, total_history_trips: 59}, null, 2));
  console.log(`Ready. 59 backend-calculated trips. Private account file: ${accountPath}`);
})().catch(error => {console.error(error.message); process.exitCode = 1;});
