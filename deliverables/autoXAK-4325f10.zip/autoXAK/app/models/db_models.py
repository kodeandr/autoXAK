import uuid
from datetime import datetime, timezone
from sqlalchemy import (
    Column,
    String,
    Float,
    Integer,
    Boolean,
    DateTime,
    ForeignKey,
    Index, JSON
)
from sqlalchemy.orm import relationship
from app.core.database import Base


class FuelRegionalPrice(Base):
    __tablename__ = "fuel_regional_prices"

    id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    region_code = Column(String(10), nullable=False, index=True)
    region_name = Column(String(100), nullable=False)
    brand = Column(String(50), nullable=False, index=True)
    brand_display_name = Column(String(100), nullable=False)

    price_ai92 = Column(Float, nullable=False)
    price_ai95 = Column(Float, nullable=False)
    price_ai100 = Column(Float, nullable=False)
    price_dt = Column(Float, nullable=False)

    availability_status = Column(String(30), default="NORMAL")
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )

    __table_args__ = (
        Index("ix_fuel_region_brand", "region_code", "brand", unique=True),
    )


class VehicleMake(Base):
    __tablename__ = "vehicle_makes"

    id = Column(String(50), primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    country = Column(String(50), nullable=True)

    models = relationship("VehicleModel", back_populates="make", cascade="all, delete-orphan")


class VehicleModel(Base):
    __tablename__ = "vehicle_models"

    id = Column(String(80), primary_key=True)
    make_id = Column(String(50), ForeignKey("vehicle_makes.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(100), nullable=False)
    body_type = Column(String(50), nullable=False)

    make = relationship("VehicleMake", back_populates="models")
    trims = relationship("VehicleTrim", back_populates="model", cascade="all, delete-orphan")


class VehicleTrim(Base):
    __tablename__ = "vehicle_trims"

    id = Column(String(100), primary_key=True)
    model_id = Column(String(80), ForeignKey("vehicle_models.id", ondelete="CASCADE"), nullable=False)
    badge_name = Column(String(120), nullable=False)

    curb_weight_kg = Column(Float, nullable=False)
    drag_coefficient_area = Column(Float, nullable=False)
    rolling_resistance_coeff = Column(Float, default=0.012)
    drivetrain_efficiency = Column(Float, default=0.90)

    base_city_fuel_rate_l100km = Column(Float, nullable=True)
    fuel_rate_source = Column(String(200), nullable=True)
    engine_displacement_l = Column(Float, nullable=False)
    rated_power_kw = Column(Float, nullable=False)
    drivetrain_type = Column(String(20), default="FWD")
    transmission_type = Column(String(20), default="AT")

    oil_capacity_l = Column(Float, nullable=False)
    oil_grade = Column(String(20), nullable=False)
    oil_spec = Column(String(50), nullable=False)
    recommended_oil_brand = Column(String(100), default="LUKOIL GENESIS")
    nominal_service_hours = Column(Float, default=250.0)

    model = relationship("VehicleModel", back_populates="trims")


class User(Base):
    __tablename__ = "users"

    id = Column(String(64), primary_key=True, index=True)
    is_guest = Column(Boolean, default=True, nullable=False)
    name = Column(String(100), nullable=True)
    email = Column(String(128), unique=True, nullable=True)
    hashed_password = Column(String(256), nullable=True)
    login = Column(String(15), nullable=True)
    merged_into = Column(String(64), nullable=True)

    __table_args__ = (Index("ix_users_login", "login", unique=True),)

    car_id = Column(String(100), default="haval_jolion_15t_4wd")
    car_name = Column(String(200), nullable=True)
    custom_profile = Column(JSON, nullable=True)
    fuel_price_rub = Column(Float, default=72.40)
    service_cost_rub = Column(Float, default=9500.0)

    # Накопительная виртуальная копилка и общая статистика
    total_savings_rub = Column(Float, default=0.0, nullable=False)
    total_fuel_saved_liters = Column(Float, default=0.0, nullable=False)
    range_bank_km = Column(Float, default=0.0, nullable=False)
    total_distance_km = Column(Float, default=0.0, nullable=False)
    total_trips = Column(Integer, default=0, nullable=False)
    current_oil_wear_percent = Column(Float, default=0.0, nullable=False)

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    trips = relationship("Trip", back_populates="user", cascade="all, delete-orphan")
    leads = relationship("CPALead", back_populates="user", cascade="all, delete-orphan")

    @property
    def user_id(self) -> str:
        return self.id

    @user_id.setter
    def user_id(self, val: str) -> None:
        self.id = val

    def __init__(self, **kwargs):
        if "user_id" in kwargs and "id" not in kwargs:
            kwargs["id"] = kwargs.pop("user_id")
        super().__init__(**kwargs)


class Trip(Base):
    __tablename__ = "trips"

    id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    car_id = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    client_session_id = Column(String(128), nullable=True)
    request_hash = Column(String(64), nullable=True)
    calculation_result = Column(JSON, nullable=True)

    # Базовые параметры движения
    duration_seconds = Column(Float, nullable=False)
    distance_km = Column(Float, nullable=False)
    equivalent_engine_hours = Column(Float, default=0.0, nullable=False)
    oil_wear_percent = Column(Float, default=0.0, nullable=False)
    idle_ratio = Column(Float, default=0.0)

    # Финансовые показатели и топливо
    fuel_saved_rub = Column(Float, default=0.0)
    oil_saved_rub = Column(Float, default=0.0)
    total_savings_rub = Column(Float, default=0.0)
    fuel_saved_liters = Column(Float, default=0.0)
    range_bonus_km = Column(Float, default=0.0)

    # Аналитика стиля вождения (Связка «стиль -> рубли» по пункту 7 Зои)
    smooth_score = Column(Integer, default=100)
    harsh_accel_count = Column(Integer, default=0)
    harsh_brake_count = Column(Integer, default=0)
    road_anomalies_count = Column(Integer, default=0)
    rush_cost_rub = Column(Float, default=0.0)
    traffic_jam_seconds = Column(Float, default=0.0)
    # Расход по бортовому компьютеру ТС (Ground Truth для ML)
    board_computer_consumption_l100km = Column(Float, nullable=True)

    user = relationship("User", back_populates="trips")

    __table_args__ = (
        Index("ix_trips_user_created", "user_id", "created_at"),
        Index("ix_trips_user_client_session", "user_id", "client_session_id", unique=True),
    )

    @property
    def session_id(self) -> str:
        return self.id

    @session_id.setter
    def session_id(self, val: str) -> None:
        self.id = val

    def __init__(self, **kwargs):
        if "session_id" in kwargs and "id" not in kwargs:
            kwargs["id"] = kwargs.pop("session_id")
        super().__init__(**kwargs)


class CPALead(Base):
    __tablename__ = "cpa_leads"

    id = Column(String(64), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    car_id = Column(String(100), nullable=False)
    partner_id = Column(String(64), nullable=False)
    promo_code = Column(String(64), nullable=False)
    discount_rub = Column(Float, default=500.0)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="leads")

class LoginAttempt(Base):
    __tablename__ = "login_attempts"
    key = Column(String(64), primary_key=True)
    failures = Column(Integer, nullable=False, default=0)
    window_started_at = Column(DateTime(timezone=True), nullable=False)
    blocked_until = Column(DateTime(timezone=True), nullable=True)


class TripTelemetryRecord(Base):
    """Immutable full derived stream; original GPS/IMU remain in RecordingChunk."""
    __tablename__ = "trip_telemetry"
    trip_id = Column(String(64), ForeignKey("trips.id", ondelete="CASCADE"), primary_key=True)
    payload = Column(JSON, nullable=False)
